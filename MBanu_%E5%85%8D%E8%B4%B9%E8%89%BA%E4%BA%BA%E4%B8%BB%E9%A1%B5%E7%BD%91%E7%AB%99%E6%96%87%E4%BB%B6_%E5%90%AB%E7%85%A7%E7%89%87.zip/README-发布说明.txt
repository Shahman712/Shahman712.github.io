# MBanu 官方艺人主页（免费静态网站）

本文件夹可发布到 GitHub Pages。网站会获得 `https://你的用户名.github.io/` 形式的网址，无需购买域名。

## 发布步骤
1. 注册/登录 https://github.com/
2. 创建一个 **Public** repository，仓库名必须是 `你的GitHub用户名.github.io`
3. 将本文件夹里的 `index.html` 上传到仓库根目录（不要只上传外层文件夹）
4. 打开仓库 **Settings → Pages**，在 Build and deployment 里选择 **Deploy from a branch**，Branch 选择 `main`，文件夹选 `/(root)`，点击 Save
5. 等待发布，网址通常为 `https://你的GitHub用户名.github.io/`

## 发布前必须替换
- 在 `index.html` 搜索 `https://YOUR-USERNAME.github.io/`，替换为实际主页网址。
- 建议添加经授权的艺人照片、官方 Muzalar 链接和公开商务邮箱。
- 歌曲名称目前按用户提供的拼写保留；上线前逐首核对平台官方元数据。
- 仅发布你愿意公开的信息。出生日期等个人信息已放入页面，若不希望公开请删除。

## 搜索引擎收录
网站发布后，打开 Google Search Console 添加网站并验证所有权，然后提交首页网址请求编入索引。收录和 AI 检索不保证立即发生，也无法保证所有 AI 都会显示此页面。


## 艺人照片
已将用户提供的4张图片放入 images/ 文件夹，并在主页中使用。请确认拥有公开发布这些照片及封面图的权利。上传网站时必须一并上传整个 images 文件夹，保持目录结构不变。
